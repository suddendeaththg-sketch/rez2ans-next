# Rez2ANS Next User Guide

Rez2ANS Next is the Qt 6 desktop rewrite of Rez2ANS. It converts ordinary
images into authentic 16-color CP437 ANSI art and TheDraw BinaryText with
optional AI-assisted shaping.

## What the package installs

The Debian package installs only the end-user application:

- `rez2ans-next` in `/usr/bin`
- a desktop launcher in the system application menu
- an application icon
- bundled documentation in `/usr/share/doc/rez2ans-next`

Retraining tools, Python, and source code are intentionally not included in the
end-user package.

## Runtime requirements

Rez2ANS Next needs a working Qt 6 desktop stack with Qt Quick and Qt Quick
Controls 2 runtime modules. The Debian package declares the shared-library
dependencies automatically, but a very minimal system still needs its normal
graphics stack and OpenGL/EGL support available.

## Basic workflow

1. Launch `Rez2ANS Next v3.2`.
2. Open a source image.
3. Drag over the source preview to choose the crop to convert.
4. Choose a **Quick Start** preset. Balanced ANSI is the recommended default.
5. Use **Render ANSI** to generate the ANSI preview.
6. Choose **Export ANSI + PNG** for a ready-to-share pair, or save ANSI,
   TheDraw BIN, or PNG individually.

## Quick Start presets

- **Balanced ANSI**: dependable general-purpose 80-column conversion.
- **BBS logo**: stronger shaping and cleaner, flatter source colors.
- **Portrait / mascot**: more detail and color preservation at 100 columns.
- **Tall scroller**: 80-column settings designed for vertically long artwork.

Presets are starting points, not locked modes. You can adjust every control
after applying one.

## Main controls

### Selection

The source pane lets you drag a rectangular crop. After creating it, drag
inside the crop to move it, or drag one of its four corner handles to resize
it. The row count recommendation tracks the crop using the 8x16 terminal cell
aspect ratio.

### Sampling

Sampling width and height define how densely each output cell examines the
source image. Larger sampling areas preserve more local detail but may smooth
less aggressively.

### Metric

The renderer supports RGB, luma-weighted RGB, CIE76, CIE94, CIEDE2000, CMC,
Oklab, and ANSI Artistic. ANSI Artistic biases matching toward visually stable
VGA color families.

### AI freedom

- Low values keep the output close to the strict optical match.
- Mid values allow smoothing, shaping, and color continuity.
- High values allow broader rework of glyphs, shades, and color assignments.

### Shading

Shading enables use of CP437 `░`, `▒`, and `▓`. Lower values use them
conservatively. Higher values allow stronger shade ramps.

### iCE colors

When enabled, backgrounds may use all 16 VGA colors and the output is marked as
iCE in SAUCE. When disabled, backgrounds are restricted to colors 0 through 7,
which is safer for blink-based viewers.

## Save formats

### ANSI

ANSI export writes escape sequences plus a SAUCE record.

### TheDraw BIN

BIN export writes CP437 character and attribute pairs plus SAUCE. BIN requires
an even width and supports up to 510 columns.

### PNG

**Save PNG** writes the rendered ANSI preview as a lossless PNG at authentic
8×16-pixel CP437 cell resolution. The export preserves the preview's CP437
glyphs, VGA colors, and canvas dimensions.

### Export ANSI + PNG

The quick export button writes both an `.ans` file with SAUCE and a PNG preview
to the persistent output folder. Files use the source image name where
possible. **Open Output Folder** opens that location directly.

## Source editor

The source editor works non-destructively from the original image. It includes
exposure, brightness, contrast, gamma, saturation, vibrance, hue, RGB balance,
tonal controls, outlines, dithers, blur, sharpen, posterization, and other
filters used to shape the source before ANSI conversion.

## About

Rez2ANS Next v3.2 is Freewarez by Dennis Martin AKA Sudden Death.
Contact: `suddendeath@email.com`
