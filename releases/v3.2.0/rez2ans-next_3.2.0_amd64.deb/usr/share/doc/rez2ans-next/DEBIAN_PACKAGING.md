# Rez2ANS Next Debian Packaging

This project can produce a Debian package for the Qt GUI application.

## Build a package

From the repository root:

```bash
./debian/make-deb.sh
```

The script configures a dedicated build tree, builds the GUI, runs the core
tests, and then generates a `.deb` with CPack.

## Package contents

The package installs:

- `/usr/bin/rez2ans-next`
- `/usr/share/applications/rez2ans-next.desktop`
- `/usr/share/pixmaps/rez2ans-next.png`
- `/usr/share/doc/rez2ans-next/README.md`
- `/usr/share/doc/rez2ans-next/USER_GUIDE.md`
- `/usr/share/doc/rez2ans-next/DEBIAN_PACKAGING.md`

## Dependency handling

The package declares the required Qt 6, Vulkan, system, and QML runtime
modules. Debian 13 and Ubuntu 24.04/Mint use different package names for Qt
Core and Qt Gui after the 64-bit `time_t` transition, so the package uses
Debian dependency alternatives:

- Debian: `libqt6core6` and `libqt6gui6`
- Ubuntu 24.04/Mint: `libqt6core6t64` and `libqt6gui6t64`

APT selects the package names appropriate to the target distribution; users do
not need to create a compatibility shim.
