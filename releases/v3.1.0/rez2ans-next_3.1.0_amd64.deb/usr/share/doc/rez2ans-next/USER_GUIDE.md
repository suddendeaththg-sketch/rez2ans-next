# Rez2ANS Next User Guide

Rez2ANS Next is the Qt 6 desktop rewrite of Rez2ANS. It converts ordinary
images into authentic 16-color CP437 ANSI art and TheDraw BinaryText with
optional AI-assisted shaping.

## What the package installs

The Debian package installs only the end-user application:

- `rez2ans-next` in `/usr/bin`
- a desktop launcher in the system application menu
- an application icon
- bundled documentation in `/usr/share/doc/rez2ans-next`

Retraining tools, Python, and source code are intentionally not included in the
end-user package.

## Runtime requirements

Rez2ANS Next needs a working Qt 6 desktop stack with Qt Quick and Qt Quick
Controls 2 runtime modules. The Debian package declares the shared-library
dependencies automatically, but a very minimal system still needs its normal
graphics stack and OpenGL/EGL support available.

## Basic workflow

1. Launch `Rez2ANS v3.1`.
2. Open a source image.
3. Drag over the source preview to choose the crop to convert.
4. Adjust columns, rows, sampling size, metric, shading, and AI freedom.
5. Use **Render Preview** to generate the ANSI preview.
6. Save as ANSI, TheDraw BIN, or a PNG preview.

## Main controls

### Selection

The source pane lets you drag a rectangular crop. The row count recommendation
tracks the crop using the 8x16 terminal cell aspect ratio.

### Sampling

Sampling width and height define how densely each output cell examines the
source image. Larger sampling areas preserve more local detail but may smooth
less aggressively.

### Metric

The renderer supports RGB, luma-weighted RGB, CIE76, CIE94, CIEDE2000, CMC,
Oklab, and ANSI Artistic. ANSI Artistic biases matching toward visually stable
VGA color families.

### AI freedom

- Low values keep the output close to the strict optical match.
- Mid values allow smoothing, shaping, and color continuity.
- High values allow broader rework of glyphs, shades, and color assignments.

### Shading

Shading enables use of CP437 `░`, `▒`, and `▓`. Lower values use them
conservatively. Higher values allow stronger shade ramps.

### iCE colors

When enabled, backgrounds may use all 16 VGA colors and the output is marked as
iCE in SAUCE. When disabled, backgrounds are restricted to colors 0 through 7,
which is safer for blink-based viewers.

## Save formats

### ANSI

ANSI export writes escape sequences plus a SAUCE record.

### TheDraw BIN

BIN export writes CP437 character and attribute pairs plus SAUCE. BIN requires
an even width and supports up to 510 columns.

### PNG

**Save PNG** writes the rendered ANSI preview as a lossless PNG at authentic
8×16-pixel CP437 cell resolution. The export preserves the preview's CP437
glyphs, VGA colors, and canvas dimensions.

## Source editor

The source editor works non-destructively from the original image. It includes
exposure, brightness, contrast, gamma, saturation, vibrance, hue, RGB balance,
tonal controls, outlines, dithers, blur, sharpen, posterization, and other
filters used to shape the source before ANSI conversion.

## About

Rez2ANS v3.1 is Freewarez by Dennis Martin AKA Sudden Death.
Contact: `suddendeath@email.com`
