# Rez2ANS v3.1

Rez2ANS v3.1 is the C++20/Qt 6 image-to-ANSI converter with a local trained
ANSI artist. Release builds display a `YYMMDD` build stamp and are distributed
as Freewarez by Dennis Martin AKA Sudden Death.

The rewrite separates three jobs:

- `rez2ans_core`: deterministic CP437/VGA candidate generation, contextual
  artist scoring, preview rendering, and ANSI/TheDraw BinaryText output.
- `rez2ans-next`: Qt Quick GUI. It loads ordinary images through `QImage` and
  provides an interactive source crop, selectable color metrics, configurable
  per-cell sampling, and worker rendering with real progress and cancellation.
  Rendered ANSI previews can also be saved as lossless PNG images at their
  authentic 8×16-pixel CP437 cell resolution.
- The local Python trainer learns a contextual ranker from real ANSI/ASC/BIN
  artwork and generates dependency-free C++ weights consumed through the
  stable `ArtistModel` boundary.

## Build now

The native core, tests, and PPM CLI do not require Qt:

```bash
cmake -S rez2ans-next -B rez2ans-next/build -DREZ2ANS_BUILD_GUI=OFF
cmake --build rez2ans-next/build -j
ctest --test-dir rez2ans-next/build --output-on-failure
```

Convert a binary PPM image while the GUI dependencies are unavailable:

```bash
rez2ans-next/build/rez2ans-next-cli input.ppm output.ans \
  --columns 80 --metric ansi --sample-width 12 --sample-height 24 \
  --artist 75 --preview preview.ppm
```

Use an output name ending in `.bin` to write TheDraw BinaryText. iCE colors are
enabled by default; add `--no-ice` when the target viewer needs blinking text
instead of bright background colors.

## Qt GUI dependencies

The GUI target needs Qt 6.4 or newer with Core, Quick, QML, Quick Controls 2,
and Concurrent development packages. Configure without
`-DREZ2ANS_BUILD_GUI=OFF`; CMake creates `rez2ans-next` when those packages are
found and otherwise continues building the core and CLI.

On Ubuntu 24.04, install them with:

```bash
sudo apt-get install qt6-base-dev qt6-declarative-dev \
  qml6-module-qtquick qml6-module-qtquick-controls \
  qml6-module-qtquick-dialogs qml6-module-qtquick-layouts \
  qml6-module-qtquick-templates qml6-module-qtquick-window \
  qml6-module-qtqml qml6-module-qtqml-models \
  qml6-module-qtqml-workerscript
```

Then build and launch:

```bash
cmake -S . -B build -DREZ2ANS_BUILD_GUI=ON
cmake --build build -j
./build/rez2ans-next
```

Build a Debian package for end users:

```bash
./debian/make-deb.sh
```

This produces a `.deb` for the GUI application.

Build a portable AppImage (after installing `linuxdeploy`, its Qt plugin, and
`appimagetool`):

```bash
./build-appimage.sh
```

The release artifact is written to `release/`.

Build a portable Flatpak bundle with the KDE Qt runtime:

```bash
flatpak-builder --user --install-deps-from=flathub build-flatpak \
  flatpak/com.suddendeaththgsketch.Rez2ANSNext.yml
```

The Flatpak uses the CPU conversion path and can be slower than the native
Debian package or AppImage on systems where Vulkan acceleration is available.
See [Flatpak packaging](docs/FLATPAK_PACKAGING.md) for the complete bundle
workflow.

Create a Windows zip release:

```bash
./build-windows-zip.sh
```

On a real Windows machine, use:

```bat
rez2ans-next\build-windows.cmd
```

In the source pane, drag over the fitted image to choose exactly what gets
converted; **Full** restores the entire image. The recommended row count updates
live while the crop is dragged, using the authentic 8x16 CP437 cell aspect.
Sampling width/height controls how densely each output cell examines the crop;
it does not stretch the preview or saved ANSI.
The preview is displayed at true 1:1 terminal size—an 80x25 canvas is exactly
640x400 pixels—and uses scrollbars instead of scaling larger ANSI canvases.

Use **Source Editor** before rendering to open the non-destructive image
adjustment drawer. It restores the original editor's exposure, brightness,
contrast, gamma, saturation, vibrance, hue, RGB balance, tonal ranges,
black/white points, posterization, invert, grayscale, flattening, pixelization,
vector styling, four outline modes, 14 color grades, cartoon, blur, sharpen,
2x2 filters, five VGA dithers, auto levels, and bilateral filtering. Changes
are rebuilt from the untouched original image on a worker thread, so repeatedly
moving controls does not accumulate quality loss. **Show original** temporarily
compares the source without changing what will be converted, and **Reset All**
returns every adjustment to its neutral value. ANSI rendering always uses the
adjusted image and the selected crop.

Available palette metrics are plain RGB, luminance-weighted RGB, CIE76, CIE94,
CIEDE2000, CMC l:c (2:1), Oklab, and ANSI Artistic. ANSI Artistic adds
hue-family and saturation preservation to the perceptual distance so saturated
source regions are less likely to drift into the wrong VGA color family.

The Shading control performs optical foreground/background palette-pair
matching for the authentic CP437 `░`, `▒`, and `▓` masks. Zero disables shade
glyphs; increasing it admits progressively stronger shade ramps when their
optical reconstruction remains close to the best hard-block candidate.

## iCE colors, TheDraw BIN, and SAUCE

The **iCE colors** switch controls both rendering and saved files. When it is
on, foreground and background may use all 16 VGA colors; background colors
8–15 occupy the DOS blink bit and SAUCE declares iCE mode. When it is off,
backgrounds are restricted to colors 0–7 and the blink bit remains clear.

**Save ANSI** writes ANSI escape sequences followed by SAUCE. **Save BIN**
writes one CP437 character/attribute pair per cell in TheDraw BinaryText format,
also followed by SAUCE. BinaryText requires an even width no greater than 510
columns, so the BIN button is unavailable for odd column counts. The metadata
editor accepts the standard 35-character title, 20-character author and group,
and newline-separated 64-character comments. Both exporters record the format,
canvas dimensions, IBM VGA font, aspect and letter-spacing flags, payload size,
and current iCE setting in the SAUCE00 record.

## Train the C++ artist locally

The rewrite uses the same incremental model and `.anr2` training records as
the Lazarus version. Each invocation discovers extensions case-insensitively,
processes the next untrained batch, continues the saved model, exports the C++
weight header, and rebuilds the Qt GUI and native CLI:

```bash
./aitrain-next.sh 10 40 /home/sudndeath/fire
```

Run it again for the next batch. Adding more `.ans`, `.ANS`, `.asc`, or `.bin`
files to that directory makes them eligible automatically. The saved model and
processed-file ledger live under `training/`; the generated runtime weights are
compiled into the application, so Python is not needed when converting images.

At **AI Freedom 0%** (**Exact**), rendering uses one optical candidate per glyph
family and the model cannot alter its color choice. Above zero, each glyph also
receives alternate VGA foreground/background pairs that the learned ranker may
choose for stronger color continuity and shaping. **Shape** (55%) adds a
full-grid neighborhood refinement pass. **Rework** (100%) uses the widest
54-candidate search and two refinement passes, allowing the artist to smooth
regions, reshape glyph runs, reorganize shades, and deliberately change colors.
The output remains authentic 16-color CP437 ANSI at every setting.

## Model contract

`ArtistModel` receives one row for each of the nine legal output candidates:
space, full block, four half blocks, and the three CP437 shades. Each row uses
the production 32-feature training contract: relative and absolute
reconstruction quality, color and luminance agreement, edge
orientation, glyph identity and coverage, four-neighbor glyph/color coherence,
source color family, saturation, variation, and the optical baseline candidate.
The renderer first creates a complete baseline grid, then ranks each cell with
all four baseline neighbors available. This matches the real-art exporter while
the renderer continues to guarantee legal ANSI cells.
