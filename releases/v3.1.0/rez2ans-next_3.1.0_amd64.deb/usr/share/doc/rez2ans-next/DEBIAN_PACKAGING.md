# Rez2ANS Next Debian Packaging

This project can produce a Debian package for the Qt GUI application only.
Retraining tools are not part of the package.

## Build a package

From the repository root:

```bash
./rez2ans-next/debian/make-deb.sh
```

The script configures a dedicated build tree, builds the GUI, runs the core
tests, and then generates a `.deb` with CPack.

## Package contents

The package installs:

- `/usr/bin/rez2ans-next`
- `/usr/share/applications/rez2ans-next.desktop`
- `/usr/share/pixmaps/rez2ans-next.png`
- `/usr/share/doc/rez2ans-next/README.md`
- `/usr/share/doc/rez2ans-next/USER_GUIDE.md`
- `/usr/share/doc/rez2ans-next/DEBIAN_PACKAGING.md`

## Dependency handling

Shared-library dependencies are resolved through `dpkg-shlibdeps`, so the
generated package depends on the Qt 6 and system runtime libraries actually
linked by the built executable.

QML runtime modules remain a system requirement on the target machine.
